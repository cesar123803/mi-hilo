<?php 
    include('../conexion/conexion.php');
    include('../modelos/documentosModelos.php');
?>
<?php
$obj = new Documento();
if($_POST){
    
    $obj->codigoDocumento = $_POST['codigoDocumento'];
    $obj->nombreDocumento = $_POST['nombreDocumento'];
}
?>
<?php
$llave = $_GET['key'];
//echo $llave;
if(isset($_POST['elimina'])){

        $obj->codigoDocumento = "";
        $obj->nombreDocumento = "";

}else{

        $clas = new Conexion();
        $conecta = $clas->conectarServidor();
        $query = "select * from documentos where codigoDocumento = '$llave'";
        $resultado = mysqli_query($conecta,$query);
        $arreglo = mysqli_fetch_row($resultado);
        $obj->codigoDocumento = $arreglo[0];
        $obj->nombreDocumento = $arreglo[1];
    }


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documentos</title>
</head>
<body>
    <center>
    <form action="" method="POST">
        <h2>Eliminar Documentos</h2>
        <table border="1">
            <tr>
                <td>Código</td>
                <td><input type="text" name="codigoDocumento" id="codigoDocumento" value="<?php echo $obj->codigoDocumento ?>" readOnly placeholder="Codigo Asignado por el Sistema" readOnly size="30"></td>
            </tr>
            <tr>
                <td>Nombre</td>
                <td><input type="text" name="nombreDocumento" id="nombreDocumento" value="<?php echo $obj->nombreDocumento ?>" readOnly placeholder="Digite el nombre del Documento" size="45"></td>
            </tr>
            <tr>
                <td colspan="2">
                    <center>
                        <button name="elimina" type="submit"> Eliminar</button>

                        <a href="documentos.php">
                            <button name="salir" type="button">Salir</button>
                        </a>
                    </center>
                </td>
            </tr>

        </table>
    </form>
    </center>    
    
</body>
</html>