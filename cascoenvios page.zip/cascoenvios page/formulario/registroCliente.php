<?php 
    include('../conexion/conexion.php');
    include('../modelos/clientesModelos.php');
?>
<?php
$obj = new Cliente();
if($_POST){
    $obj->documentocliente = $_POST['documentocliente'];
    $obj->codigoDocumento = $_POST['codigoDocumento'];
    $obj->nombrecliente = $_POST['nombrecliente'];
    $obj->apellidocliente = $_POST['apellidocliente'];
    $obj->telefonocliente1 = $_POST['telefonocliente1'];
    $obj->telefonocliente2 = $_POST['telefonocliente2'];
    $obj->ciudadcliente = $_POST['telefonocliente'];
    $obj->correocliente = $_POST['correocliente'];
    $obj->contraseñacliente = $_POST['contraseñacliente'];
    $obj->confirmarcontraseñacliente = $_POST['contraseñacliente'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes</title>
</head>
<body>
    <center>
    <form action="" name="cliente" id="cliente" method="POST">
        <h2>Registro Cliente</h2>
        <p><strong>El siguiente formulario es necesario diligenciar para el uso optimo de nuestros servicios agradecemos su comprension.</strong></p>
        <table border="1">
            <tr>
                <td>Numero Documento</td>
                <td><input type="text" name="documentocliente" id="documentocliente" placeholder="Digite el Documento del Cliente"  size="30"></td>
            
                <td>Seleccione el Documento</td>
                <td><input type="text" name="codigoDocumento" id="codigoDocumento"  size="45"></td>
            </tr>
            <tr>
                <td>Nombre</td>
                <td><input type="text" name="nombrecliente" id="nombrecliente" placeholder="Digite el Nombre del Cliente"  size="45"></td>
            
                <td>Apellido</td>
                <td><input type="text" name="apellidocliente" id="apellidocliente" placeholder="Digite el Apellido del Cliente"  size="45"></td>
            </tr>
            <tr>
                <td>Telefono1</td>
                <td><input type="text" name="telefonocliente1" id="telefonocliente1" placeholder="Digite el Telefono del Cliente"  size="45"></td>
            
                <td>Telefono2</td>
                <td><input type="text" name="telefonocliente2" id="telefonocliente2" placeholder="Digite el Telefono del Cliente"  size="45"></td>
            </tr>
                <td>ciudadCliente</td>
                <td><input type="text" name="ciudadcliente" id="ciudadcliente" placeholder="Digite el Nombre de la Ciudad"  size="45"></td>
            
                <td>Correo Electronico</td>
                <td><input type="text" name="correocliente" id="correocliente" placeholder="Digite el Correo del Cliente"  size="45"></td>
            </tr>            
            <tr>
                <td>contraseña</td>
                <td><input type="number" name="contraseñacliente" id="contraseñacliente" placeholder="Digite el Numero de Contraseña"  size="45"></td>
            
                <td>Confirmar contraseña</td>
                <td><input type="number" name="confirmarcontraseñacliente" id="confirmarcontraseñacliente" placeholder="Confirme el Numero de Contraseña"  size="45"></td>
            </tr>
            <tr>

            <tr>
                <td colspan="4">
                    <center>
                        <button name="agregar" type="submit"> Guardar</button>
                        <a href="clientes.php">
                            <button name="salir" type="button">Salir</button>
                        </a>
                    </center>
                </td>
            </tr>

        </table>
        

    </form>
    </center>    
    
</body>
</html>