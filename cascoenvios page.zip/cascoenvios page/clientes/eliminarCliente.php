<?php
include('../conexion/conexion.php');
include('../modelos/clientesModelos.php');
?>
<?php
$obj = new Cliente();
if ($_POST) {
    $obj->documentocliente = $_POST['documentoCliente'];
    $obj->codigoDocumento = $_POST['codigoDocumento'];
    $obj->nombrecliente = $_POST['nombreCliente'];
    $obj->apellidocliente = $_POST['apellidoCliente'];
    $obj->telefonocliente = $_POST['telefonoCliente'];
    $obj->contraseñacliente = $_POST['contraseñaCliente'];
    $obj->ciudadcliente = $_POST['ciudadCliente'];
    $obj->correocliente = $_POST['correoCliente'];
}
?>
<?php
$llave = $_GET['key'];
echo $llave;
if (isset($_POST['eliminar'])) {

    $obj->documentocliente = "";
    $obj->codigoDocumento = "";
    $obj->nombrecliente = "";
    $obj->apellidocliente = "";
    $obj->telefonocliente = "";
    $obj->contraseñacliente = "";
    $obj->ciudadcliente = "";
    $obj->correocliente = "";
} else {

    $clas = new Conexion();
    $conecta = $clas->conectar_al_servidor();
    $query = "select * from clientes where documentocliente = '$llave'";
    $resultado = mysqli_query($conecta, $query);
    $arreglo = mysqli_fetch_row($resultado);
    $obj->documentocliente = $arreglo[0];
    $obj->codigoDocumento = $arreglo[1];
    $obj->nombrecliente = $arreglo[2];
    $obj->apellidocliente = $arreglo[3];
    $obj->telefonocliente = $arreglo[4];
    $obj->contraseñacliente = $arreglo[5];
    $obj->ciudadcliente = $arreglo[6];
    $obj->correocliente = $arreglo[7];
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes</title>
     <link rel="stylesheet" href="../CSS/eestilos_php.css">
</head>

<body>

    <header>
        <section class="body_estilo">

            <center>
                <form action="" method="POST">
                    <h2>Eliminar Clientes</h2>
                    <table border="1">
                        <tr>
                            <td>Numero Documento</td>
                            <td><input type="text" name="documentocliente" id="documentocliente" value="<?php echo $obj->documentocliente  ?>" readOnly placeholder="Digite el Documento del Cliente" size="30"></td>

                            <td>Seleccione el Documento</td>
                            <td><input type="checkbox" name="codigoDocumento" id="codigoDocumento" value="<?php echo $obj->codigoDocumento  ?>" readOnly size="45"></td>
                        </tr>
                        <tr>
                            <td>Nombre</td>
                            <td><input type="text" name="nombrecliente" id="nombrecliente" value="<?php echo $obj->nombrecliente  ?>" readOnly placeholder="Digite el Nombre del Cliente" size="45"></td>

                            <td>Apellido</td>
                            <td><input type="text" name="apellidocliente" id="apellidocliente" value="<?php echo $obj->apellidocliente  ?>" readOnly placeholder="Digite el Apellido del Cliente" size="45"></td>
                        </tr>
                        <tr>
                            <td>Telefono</td>
                            <td><input type="number" name="telefonocliente" id="telefonocliente" value="<?php echo $obj->telefonocliente  ?>" readOnly placeholder="Digite el Telefono del Cliente" size="45"></td>

                            <td>contraseña</td>
                            <td><input type="password" name="contraseñacliente" id="contraseñacliente" value="<?php echo $obj->contraseñacliente  ?>" readOnly placeholder="Digite la contraseña del Cliente" size="45"></td>
                        </tr>
                        <tr>
                            <td>Ciudad</td>
                            <td><input type="text" name="ciudadcliente" id="ciudadcliente" value="<?php echo $obj->ciudadcliente  ?>" readOnly placeholder="Digite la ciudad del Cliente" size="45"></td>

                            <td>Correo Electronico</td>
                            <td><input type="email" name="correocliente" id="correocliente" value="<?php echo $obj->correocliente  ?>" readOnly placeholder="Digite el Correo del Cliente" size="45"></td>
                        </tr>
                        <tr>
                        <tr>
                            <td colspan="4">
                                <center>
                                    <button name="eliminar" type="submit"> Eliminar</button>

                                    <a href="clientes.php">
                                        <button name="salir" type="button">Salir</button>
                                    </a>
                                </center>
                            </td>
                        </tr>

                    </table>
                </form>
            </center>
        </section>
    </header>
</body>

</html>