<?php
    class Cliente{
                    public $documentocliente;
                    public $codigoDocumento;
                    public $nombrecliente;
                    public $apellidocliente;
                    public $telefonocliente;
                    public $correocliente;
                    public $ciudadcliente;
                    public $contrasenacliente;

                    function agregarCliente(){
                        $clas = new Conexion();
                        $conecta = $clas->conectar_al_servidor();
                        $consulta = "select * from clientes where documentocliente = '$this->documentoCliente'";
                        $resultado = mysqli_query($conecta, $consulta);
                        if(mysqli_fetch_array($resultado)){
                            echo "<script> alert('El Cliente ya existe en el Sistema')</script>";
                        }else{
                                $insertar = "insert into clientes values('$this->documentocliente',
                                                                         '$this->codigoDocumento',
                                                                         '$this->nombrecliente',
                                                                         '$this->apellidoliente',
                                                                         '$this->telefonocliente','$this->contraseñacliente','$this->ciudadcliente',


                                                                         '$this->correocliente')";
                                echo $insertar;
                                mysqli_query($conecta,$insertar);
                                echo "<script> alert('El Cliente Fue registrado en el Sistema')</script>";
                        }


                    }

                    function modificarCliente(){
                        $clas = new Conexion();
                        $conecta = $clas->conectar_al_servidor();
                        $consulta = "select * from clientes where documentocliente = '$this->documentocliente'";
                        $resultado = mysqli_query($conecta, $consulta);
                        if(!mysqli_fetch_array($resultado)){
                            echo "<script> alert('El Cliente ya existe en el Sistema')</script>";
                        }else{
                                $modificar = "update clientes set documentoCliente =      '$this->documentocliente',
                                                                        codigoDocumento =    '$this->codigoDocumento',
                                                                        nombreCliente =      '$this->nombrecliente',
                                                                        apellidoCliente =    '$this->apellidocliente',
                                                                        telefonoCliente =    '$this->telefonocliente',
                                                                        correoCliente =      '$this->correocliente',
                                                                        ciudadCliente =
                                                                        '$this->ciudadcliente',
                                                                        contraseñaCliente =
                                                                        '$this->contraseñacliente'




                                                                    where documentocliente = '$this->documentocliente'";
                                echo $modificar;
                                mysqli_query($conecta,$modificar);                                    
                                echo "<script> alert('El Cliente Fue Modificado en el Sistema')</script>";
                        }
  

                    }

                    function eliminarCliente(){
                        $clas = new Conexion();
                        $conecta = $clas->conectar_al_servidor();
                        $eliminar="delete from clientes where documentocliente = '$this->documentocliente'";
                        echo $eliminar;
                        if(mysqli_query($conecta,$eliminar)){
                            echo "<script> alert('El Cliente Fue Eliminado en el Sistema')</script>";
                        }else{
                            echo "<script> alert('El Cliente No se puede Eliminar del Sistema, porque tiene registros relacionados')</script>";
                        }


                    }
   }   
?>