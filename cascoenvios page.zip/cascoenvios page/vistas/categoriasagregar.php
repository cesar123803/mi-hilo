<?php
    include ("../conexion/conexion.php");
    include ("../modelos/modelopedidos.php");
    $obj = new Facturas();
    if($_POST)
    {
        $obj->numeroFactura  = $_POST["numeroFactura "];
        $obj->nombreCategorias = $_POST["nombreCategorias"];


    }

?>

<!DOCTYPE html>
<html lang="ES">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width-device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/boostrap.min.css"
    <link rel="stylesheet" href="css/font.awesome.min.css"
    <link rel="stylesheet" href="css/"
    <script src="js/validate2.js/"></script>
    <title>Clientes</title>
</head>
<body>



<br>

<br>
<center>





</center>

<?php



sleep(1);

?>

<h4 class=""
<hr style="__autoload"


</body>