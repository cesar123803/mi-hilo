<?php
include('../controladores/depositoControlador.php');

$obj = new Deposito();
if($_POST){
    $obj->documentocliente = $_POST['documentocliente'];
    $obj->codigoDocumento = $_POST['codigoDocumento'];
    $obj->nombrecliente = $_POST['nombrecliente'];
    $obj->apellidocliente = $_POST['apellidocliente'];
    $obj->telefonocliente = $_POST['telefonocliente'];
    $obj->contraseñacliente = $_POST['contraseñacliente'];
    $obj->ciudadcliente = $_POST['ciudadcliente'];
    $obj->correocliente = $_POST['correocliente'];
}
if(isset($_POST['agregar'])){

    $obj->agregarDeposito();

}
if(isset($_POST['modificar'])){

    $obj->modificarDeposito();

}
if(isset($_POST['eliminar'])){

    $obj->eliminarDeposito();

}
?>