<?php
include('../controladores/clienteControlador.php');

$obj = new cliente();
if($_POST){
    $obj->documentocliente = $_POST['documentocliente'];
    $obj->codigoDocumento = $_POST['codigoDocumento'];
    $obj->nombrecliente = $_POST['nombrecliente'];
    $obj->apellidocliente = $_POST['apellidocliente'];
    $obj->telefonocliente = $_POST['telefonocliente'];
    $obj->contraseñacliente = $_POST['contraseñacliente'];
    $obj->ciudadcliente = $_POST['ciudadcliente'];
    $obj->correoCliente = $_POST['correocliente'];
}
if(isset($_POST['agregar'])){

    $obj->agregarCliente();

}
if(isset($_POST['modificar'])){

    $obj->modificarCliente();

}
if(isset($_POST['eliminar'])){

    $obj->eliminarCliente();

}
?>